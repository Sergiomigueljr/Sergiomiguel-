# Sérgio Miguel - Official Partners

Landing page oficial dos parceiros do Sérgio Miguel.

## Como publicar

1. Abra o repositório no GitHub.
2. Clique em **Add file > Upload files**.
3. Envie todos os arquivos deste pacote.
4. Clique em **Commit changes**.
5. Aguarde o GitHub Pages atualizar.

Link esperado:
https://sergiomigueljr.github.io/Sergiomiguel-/
