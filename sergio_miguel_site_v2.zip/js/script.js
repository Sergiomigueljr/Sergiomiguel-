document.querySelectorAll('.partner-card').forEach((card) => {
  card.addEventListener('touchstart', () => {
    card.style.transform = 'scale(.985)';
  }, { passive: true });

  card.addEventListener('touchend', () => {
    card.style.transform = '';
  }, { passive: true });
});
