# Sérgio Miguel - Official Partners

Site oficial dos parceiros do Sérgio Miguel.

## Publicação

Suba estes arquivos no repositório GitHub:

- index.html
- css/style.css
- js/script.js
- images/

Depois aguarde o GitHub Pages atualizar.

Link:
https://sergiomigueljr.github.io/Sergiomiguel-/
